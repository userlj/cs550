	
	Lingjie Meng
	lmeng4@binghamton.edu
	Feb 7, 2014




	1. compile the code:
		gcc -O -Wall -Wextra -o a.out malloc.c test.c

	2. run the program:
		./a.out 18 10000000




	The file malloc.c has been tested on 
	remote.cs.binghamton.edu, with no warnings 
	and does not have memory leaks.

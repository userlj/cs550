1). My information
    
    Name : LieHuo Chen
    B Num : B00442344
    Email: lchen66@binghamton.edu


2). Instruction for running the program

    a. compile the program
        make 
    b. Clean before run again
        make clean
    c. Then the test.out is the runnable program. 

3). Test myself
    
    a. I test the program on cs.remote.binghamton.edu

    b. I run the test from Professor successfully.

